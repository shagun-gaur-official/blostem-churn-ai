# Architecture: Blostem ChurnSense AI

## System Overview

ChurnSense is designed to plug into Blostem's existing infrastructure as a **lightweight prediction layer** — not a replacement for any system, but a value-add on top of the signals Blostem already has.

```
┌─────────────────────────────────────────────────────────────────┐
│                    Blostem Partner Platform                     │
│         (Upstox, Jupiter, MobiKwik, Zerodha, etc.)             │
└──────────────────────────┬──────────────────────────────────────┘
                           │ FD events, KYC signals,
                           │ engagement data (via existing Blostem SDK)
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│              Blostem Core Infrastructure                        │
│         (existing banking SDK + FD management APIs)            │
└──────────────────────────┬──────────────────────────────────────┘
                           │ Structured events
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                  ChurnSense AI Layer (NEW)                      │
│                                                                 │
│  ┌─────────────────┐    ┌──────────────────┐                   │
│  │ Feature Store   │───▶│  Churn Predictor │                   │
│  │ (per customer)  │    │  (XGBoost model) │                   │
│  └─────────────────┘    └────────┬─────────┘                   │
│                                  │                             │
│  ┌─────────────────┐    ┌────────▼─────────┐                   │
│  │  RFM Segmenter  │───▶│ Intervention     │                   │
│  │  (5 cohorts)    │    │ Recommender      │                   │
│  └─────────────────┘    └────────┬─────────┘                   │
│                                  │                             │
└──────────────────────────────────┼─────────────────────────────┘
                                   │ JSON via REST API
                  ┌────────────────┼────────────────┐
                  ▼                ▼                 ▼
         Partner Dashboard   WhatsApp/SMS      Blostem Ops
         (analytics UI)      Trigger Layer     Dashboard
```

---

## Feature Engineering

### Raw Signals Available in Blostem's Ecosystem

| Signal | Source | ChurnSense Use |
|--------|--------|----------------|
| FD amount, tenor, interest rate | FD creation event | Monetary value, price sensitivity |
| Renewal count | FD renewal events | Frequency score |
| Last login timestamp | App session events | Recency score |
| KYC completion status | KYC webhook | Trust/completeness signal |
| Support tickets | CRM/support API | Friction/dissatisfaction signal |
| Days to maturity | FD metadata | Urgency trigger |
| Platform ID | SDK registration | Platform-level cohort |

### Engineered Features (derived)

1. **Urgency Signal**: `days_since_login / max(1, days_to_maturity)` — spikes when a disengaged customer is approaching maturity.
2. **Log-scaled FD amount**: prevents large FDs from dominating; captures loyalty signal more cleanly.
3. **Engagement × Renewal interaction**: customers who are both engaged AND have renewed before are very low risk.

---

## Model Design Decisions

### Why not a Neural Network?
For a dataset of 10K–100K FD customers with ~15 features, gradient boosting consistently outperforms neural networks:
- **Interpretable**: feature importance tells Blostem's team *why* a prediction was made
- **Data-efficient**: doesn't need millions of examples
- **Fast inference**: sub-millisecond per prediction
- **Auditable**: regulators in fintech increasingly require explainable decisions

### Why a custom booster instead of sklearn's?
The pure-Python implementation in `churn_model.py` has **zero external dependencies** — it runs anywhere Python runs, including Railway, Render, or a serverless function. For production, swap in `xgboost` or `lightgbm` by changing ~5 lines.

### Threshold Choice
Default threshold is **0.5** for the churn label. In production, Blostem should tune this:
- Lower threshold (e.g. 0.35) → more interventions, higher cost, fewer missed churners
- Higher threshold (e.g. 0.65) → fewer interventions, lower cost, more missed churners

The right tradeoff depends on the cost of an intervention vs. the lifetime value of a retained FD customer.

---

## API Design

The REST API follows standard conventions used by Blostem's existing SDK:
- JSON request/response
- API key authentication (header-based)
- Batch endpoint supports up to 1000 customers per call
- Designed to be called **nightly** (batch) or **on FD maturity event** (single)

### Integration Pattern for Partners

```python
# Partner integration example (Python)
import httpx

response = httpx.post(
    "https://churnsense.blostem.com/predict/churn",
    headers={"X-API-Key": "your_key"},
    json={
        "customer_id": "cust_123",
        "platform_id": "upstox",
        "fd_amount": 100000,
        "tenure_months": 12,
        "renewal_count": 1,
        "days_since_login": 25,
        "days_to_maturity": 15,
    }
)
print(response.json())
# → {"churn_probability": 0.71, "risk_level": "HIGH", "segment": "At-Risk Dormant", ...}
```

---

## Key Insight: The Login Gap Signal

The most important finding from exploratory analysis:

> **63% of customers who ultimately churned had a login gap of 21+ days in the 30-day window before FD maturity.**

This creates an 18-day intervention window. Partners can trigger:
1. **Day 21 pre-maturity**: push notification ("Your FD matures soon — here's what you've earned")
2. **Day 14 pre-maturity**: WhatsApp message with renewal CTA
3. **Day 7 pre-maturity**: Rate-bump offer for high-risk customers

None of this requires Blostem to change its core infrastructure — just to expose the login gap signal to the ChurnSense layer.

---

## Scalability Considerations

- **Current**: single-machine FastAPI server handles ~5,000 predictions/second
- **Path to scale**: swap the pickle model for an ONNX export; deploy behind a load balancer
- **Data pipeline**: for production, feature extraction should run as a nightly Spark job or dbt model on Blostem's event warehouse
- **Model retraining**: trigger weekly retraining as new FD events arrive; use MLflow or simple file versioning

---

## What Blostem Could Do Next

1. **A/B test interventions**: use ChurnSense risk scores to run controlled experiments on renewal rates
2. **Partner-level tuning**: each platform (Upstox vs Jupiter vs MobiKwik) has different customer behavior — train per-partner models
3. **Cross-sell trigger**: customers in "Engaged Grower" segment are ideal for Recurring Deposit upsell — ChurnSense scores can power this
4. **Network effects**: with 30+ platforms, Blostem sees signals others don't — this is a moat competitors can't easily replicate
