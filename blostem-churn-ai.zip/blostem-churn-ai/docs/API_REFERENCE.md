# ChurnSense AI — API Reference

Base URL: `http://localhost:8000` (local) or your deployed URL

---

## Authentication

All endpoints require an API key in the header:
```
X-API-Key: your_key_here
```

---

## Endpoints

### `GET /health`
Returns model status and version.

**Response:**
```json
{
  "status": "ok",
  "model_loaded": true,
  "version": "1.0.0"
}
```

---

### `POST /predict/churn`
Predict churn probability for a single customer.

**Request body:**
```json
{
  "customer_id": "cust_009812",
  "platform_id": "upstox",
  "fd_amount": 150000,
  "tenure_months": 12,
  "interest_rate": 8.5,
  "renewal_count": 2,
  "days_since_login": 25,
  "app_engagement_score": 38.0,
  "rate_sensitivity": 0.6,
  "support_tickets_last_90d": 1,
  "kyc_complete": 1,
  "days_to_maturity": 15,
  "checked_competitor_fd": 0,
  "nominee_added": 1
}
```

**Response:**
```json
{
  "customer_id": "cust_009812",
  "churn_probability": 0.71,
  "risk_level": "HIGH",
  "segment": "At-Risk Dormant",
  "recommended_action": "Urgent: trigger WhatsApp outreach + offer 0.25% rate bump. Assign to partner success team.",
  "confidence": 0.855,
  "model_version": "1.0.0"
}
```

---

### `POST /predict/batch`
Predict churn for up to 1000 customers.

**Request body:**
```json
{
  "customers": [ { ...customer1... }, { ...customer2... } ]
}
```

**Response:**
```json
{
  "total": 2,
  "high_risk_count": 1,
  "results": [
    { "customer_id": "cust_002", "churn_probability": 0.82, "risk_level": "HIGH", ... },
    { "customer_id": "cust_001", "churn_probability": 0.12, "risk_level": "LOW",  ... }
  ]
}
```

---

### `GET /segments/actions`
Returns recommended interventions per segment.

---

### `GET /model/info`
Returns model metadata and last training metrics.

---

## Risk Levels

| Level | Churn Probability | Recommended Response |
|-------|------------------|----------------------|
| LOW | < 30% | Standard renewal reminder 7d before maturity |
| MEDIUM | 30–60% | Push notification + renewal CTA 14d before maturity |
| HIGH | > 60% | WhatsApp + rate bump offer + partner success call |

---

## Example: cURL

```bash
curl -X POST http://localhost:8000/predict/churn \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your_key" \
  -d '{
    "customer_id": "cust_001",
    "platform_id": "jupiter",
    "fd_amount": 75000,
    "tenure_months": 6,
    "interest_rate": 8.25,
    "renewal_count": 0,
    "days_since_login": 35,
    "app_engagement_score": 22,
    "rate_sensitivity": 0.8,
    "support_tickets_last_90d": 2,
    "kyc_complete": 1,
    "days_to_maturity": 12,
    "checked_competitor_fd": 1,
    "nominee_added": 0
  }'
```
