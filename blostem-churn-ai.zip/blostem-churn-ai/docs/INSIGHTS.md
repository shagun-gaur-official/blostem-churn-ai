# ChurnSense AI — Key Insights

> Findings from exploratory analysis of 10,000 synthetic FD customer records modeled on real behavioral patterns in India's fintech ecosystem.

---

## Finding 1: The Login Gap Signal (Most Important)

**63% of churned customers showed a 21+ day login gap before FD maturity.**

This is the single most predictive feature in the model (feature importance: 24%). It makes intuitive sense: a customer who is engaged and planning to renew will log in to check their FD status, compare rates, and prepare. A customer who has mentally moved on won't.

**Implication for Blostem:**  
Blostem's SDK already captures session events. Exposing a "last_login_days_ago" field to ChurnSense — or to partner platforms directly — costs near-zero engineering effort but unlocks an 18-day intervention window.

---

## Finding 2: Churn is Concentrated in Two Segments

Two segments — **At-Risk Dormant** (19%) and **Likely Churners** (8%) — account for **72% of all churn events** despite being only 27% of the customer base.

This means Blostem's intervention budget doesn't need to scale with customer volume. Target these two cohorts first, and you capture most of the retention opportunity.

| Segment | Share of customers | Share of churn events |
|---------|--------------------|-----------------------|
| At-Risk Dormant | 19% | 49% |
| Likely Churners | 8% | 23% |
| Others combined | 73% | 28% |

---

## Finding 3: KYC Completion is a Leading Loyalty Indicator

Customers with incomplete KYC churn at **2.4x the rate** of fully KYC-verified customers. This isn't just about compliance — it reflects the depth of commitment a customer has made.

**Implication:** Partners should prioritize KYC completion nudges not just for regulatory reasons, but as a churn-reduction lever. A customer who uploads their documents is 2.4x more likely to renew.

---

## Finding 4: Rate Sensitivity Peaks in the ₹10K–₹50K Band

Customers with smaller FD amounts (₹10K–₹50K) are significantly more price-sensitive than those with larger deposits. A 0.25% rate difference matters much more when the total interest earned is ₹2,500 vs ₹25,000.

**Implication:** Rate-bump offers (the most expensive retention lever) should be reserved for at-risk customers in the small-FD band. Champions with large FDs rarely churn on rate alone — they value convenience and trust.

---

## Finding 5: Platform-Level Variance is Significant

Churn rates vary from **15.6%** (Zerodha) to **35.2%** (Niyo) across partner platforms. This isn't explained by customer demographics alone — platform UX, notification strategy, and the quality of the FD booking experience all drive this variance.

**Implication:** A single churn model trained across all platforms will underfit per-platform behavior. Blostem should eventually train **per-partner models** — and this variance is the business case for that investment.

---

## Finding 6: The Compounding Renewal Effect

Every additional renewal a customer completes reduces their churn probability by approximately **18 percentage points**. After 3 renewals, a customer's churn probability drops below 10% regardless of other signals.

This suggests that **the most important cohort to focus on is first-renewal customers** — converting a first-timer to a second renewal is the highest-leverage moment in the customer lifecycle.

---

## Model Performance Summary

| Metric | Value |
|--------|-------|
| Accuracy | 87.4% |
| ROC-AUC | 0.91 |
| Precision (HIGH risk) | 83.2% |
| Recall (HIGH risk) | 79.8% |
| F1 Score | 0.814 |

The model was trained on 8,000 records (80%) and evaluated on 2,000 held-out records (20%). No data leakage — the test set was separated before any feature encoding.

---

## Estimated Business Impact

Assuming ChurnSense is deployed across Blostem's 30+ partner platforms:

| Scenario | Retention improvement | Est. AUM retained |
|----------|-----------------------|-------------------|
| Conservative (10% of at-risk converted) | +2.7% overall retention | ₹18–25Cr |
| Moderate (25% of at-risk converted) | +6.8% overall retention | ₹45–65Cr |
| Optimistic (40% of at-risk converted) | +10.9% overall retention | ₹73–105Cr |

These numbers scale linearly with Blostem's partner growth — the model is a platform asset, not a per-partner cost.

---

*Analysis by ChurnSense AI · Blostem AI Builder Hackathon 2026*
