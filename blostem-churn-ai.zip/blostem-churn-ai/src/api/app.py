"""
Blostem ChurnSense AI — REST API
FastAPI endpoints for churn prediction and customer segmentation.
"""

try:
    from fastapi import FastAPI, HTTPException, Header
    from fastapi.middleware.cors import CORSMiddleware
    from pydantic import BaseModel, Field
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

import json
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ── Request / Response Schemas ────────────────────────────────────────────────

if HAS_FASTAPI:
    class CustomerPredictRequest(BaseModel):
        customer_id: str = Field(..., example="cust_009812")
        platform_id: str = Field(..., example="upstox")
        bank_id: str = Field(default="suryoday_sfb", example="suryoday_sfb")
        state: str = Field(default="MH", example="MH")
        fd_amount: float = Field(..., ge=1000, example=150000)
        tenure_months: int = Field(..., ge=1, le=120, example=12)
        interest_rate: float = Field(..., ge=5.0, le=12.0, example=8.5)
        renewal_count: int = Field(default=0, ge=0, example=2)
        days_since_login: int = Field(..., ge=0, example=14)
        app_engagement_score: float = Field(default=50.0, ge=0, le=100, example=62.0)
        rate_sensitivity: float = Field(default=0.5, ge=0, le=1, example=0.4)
        support_tickets_last_90d: int = Field(default=0, ge=0, example=1)
        kyc_complete: int = Field(default=1, ge=0, le=1, example=1)
        days_to_maturity: int = Field(..., example=21)
        checked_competitor_fd: int = Field(default=0, ge=0, le=1, example=0)
        nominee_added: int = Field(default=1, ge=0, le=1, example=1)

    class PredictResponse(BaseModel):
        customer_id: str
        churn_probability: float
        risk_level: str
        segment: str
        recommended_action: str
        confidence: float
        model_version: str = "1.0.0"

    class BatchPredictRequest(BaseModel):
        customers: list[CustomerPredictRequest]

    class HealthResponse(BaseModel):
        status: str
        model_loaded: bool
        version: str

# ── App Setup ─────────────────────────────────────────────────────────────────

if HAS_FASTAPI:
    app = FastAPI(
        title="Blostem ChurnSense AI",
        description="Churn prediction and customer segmentation for Fixed Deposit platforms",
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Model state
    _model = None
    _model_loaded = False

    def get_model():
        global _model, _model_loaded
        if not _model_loaded:
            try:
                from src.models.churn_model import load_model
                _model = load_model("models/churn_v1.pkl")
                _model_loaded = True
            except Exception as e:
                print(f"Warning: Could not load trained model: {e}")
                print("Run `python src/models/churn_model.py --train` first.")
        return _model

    # ── Routes ────────────────────────────────────────────────────────────────

    @app.get("/", tags=["Info"])
    def root():
        return {
            "name": "Blostem ChurnSense AI",
            "description": "FD churn prediction & customer segmentation API",
            "docs": "/docs",
            "endpoints": ["/health", "/predict/churn", "/predict/batch", "/segments/actions"],
        }

    @app.get("/health", response_model=HealthResponse, tags=["Health"])
    def health():
        model = get_model()
        return HealthResponse(
            status="ok",
            model_loaded=model is not None,
            version="1.0.0",
        )

    @app.post("/predict/churn", response_model=PredictResponse, tags=["Prediction"])
    def predict_churn(req: CustomerPredictRequest):
        """
        Predict churn probability for a single FD customer.
        Returns risk level, segment assignment, and recommended intervention.
        """
        from src.models.churn_model import predict_single
        from src.models.segmentation import compute_rfm_scores, assign_segment

        model = get_model()
        customer_dict = req.dict()

        # Get churn prediction
        result = predict_single(customer_dict, model)

        # Get segment
        rfm_rows = compute_rfm_scores([customer_dict])
        rfm_rows[0]["blostem_segment"] = assign_segment(rfm_rows[0])
        segment = rfm_rows[0]["blostem_segment"]

        return PredictResponse(
            customer_id=result["customer_id"],
            churn_probability=result["churn_probability"],
            risk_level=result["risk_level"],
            segment=segment,
            recommended_action=result["recommended_action"],
            confidence=result["confidence"],
        )

    @app.post("/predict/batch", tags=["Prediction"])
    def predict_batch(req: BatchPredictRequest):
        """
        Predict churn for up to 1000 customers in a single request.
        Returns sorted list by churn probability (highest risk first).
        """
        if len(req.customers) > 1000:
            raise HTTPException(status_code=400, detail="Batch size limited to 1000 customers.")

        from src.models.churn_model import predict_single
        from src.models.segmentation import compute_rfm_scores, assign_segment

        model = get_model()
        results = []
        for customer in req.customers:
            customer_dict = customer.dict()
            result = predict_single(customer_dict, model)
            rfm_rows = compute_rfm_scores([customer_dict])
            rfm_rows[0]["blostem_segment"] = assign_segment(rfm_rows[0])
            result["segment"] = rfm_rows[0]["blostem_segment"]
            results.append(result)

        # Sort by risk
        results.sort(key=lambda x: x["churn_probability"], reverse=True)

        high_risk = [r for r in results if r["risk_level"] == "HIGH"]
        return {
            "total": len(results),
            "high_risk_count": len(high_risk),
            "results": results,
        }

    @app.get("/segments/actions", tags=["Segmentation"])
    def get_segment_actions():
        """Returns recommended intervention actions per customer segment."""
        from src.models.segmentation import SEGMENT_ACTIONS
        return SEGMENT_ACTIONS

    @app.get("/model/info", tags=["Info"])
    def model_info():
        """Returns model metadata and last training metrics."""
        try:
            with open("models/churn_v1_metrics.json") as f:
                metrics = json.load(f)
        except FileNotFoundError:
            metrics = {"note": "Train model first: python src/models/churn_model.py --train"}
        return {
            "model_type": "Gradient Boosted Classifier (XGBoost-style)",
            "version": "1.0.0",
            "features": 15,
            "metrics": metrics,
        }

# ── Entry Point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not HAS_FASTAPI:
        print("Install FastAPI: pip install fastapi uvicorn")
    else:
        import uvicorn
        uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
