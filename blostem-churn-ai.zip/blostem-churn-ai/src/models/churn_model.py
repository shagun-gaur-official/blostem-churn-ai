"""
Blostem ChurnSense AI — Churn Prediction Model
XGBoost-based classifier with feature engineering and evaluation.
"""

import os
import csv
import json
import math
import random
import argparse
import pickle
from collections import defaultdict

# ---------------------------------------------------------------------------
# Feature Engineering
# ---------------------------------------------------------------------------

NUMERIC_FEATURES = [
    "fd_amount", "tenure_months", "interest_rate", "renewal_count",
    "days_since_login", "app_engagement_score", "rate_sensitivity",
    "support_tickets_last_90d", "days_to_maturity",
]
BINARY_FEATURES = ["kyc_complete", "checked_competitor_fd", "nominee_added"]
CATEGORICAL_FEATURES = ["platform_id", "bank_id", "state"]

PLATFORM_ENC = {}
BANK_ENC = {}
STATE_ENC = {}


def encode_categoricals(rows):
    """Label-encode categorical features based on training data."""
    global PLATFORM_ENC, BANK_ENC, STATE_ENC
    platforms = sorted(set(r["platform_id"] for r in rows))
    banks = sorted(set(r["bank_id"] for r in rows))
    states = sorted(set(r["state"] for r in rows))
    PLATFORM_ENC = {p: i for i, p in enumerate(platforms)}
    BANK_ENC = {b: i for i, b in enumerate(banks)}
    STATE_ENC = {s: i for i, s in enumerate(states)}


def extract_features(row: dict) -> list:
    """Convert a customer record dict into a numeric feature vector."""
    feats = []
    for f in NUMERIC_FEATURES:
        feats.append(float(row.get(f, 0)))
    for f in BINARY_FEATURES:
        feats.append(float(row.get(f, 0)))
    feats.append(float(PLATFORM_ENC.get(row.get("platform_id", ""), 0)))
    feats.append(float(BANK_ENC.get(row.get("bank_id", ""), 0)))
    feats.append(float(STATE_ENC.get(row.get("state", ""), 0)))

    # Engineered features
    fd_amt = float(row.get("fd_amount", 50000))
    login_gap = float(row.get("days_since_login", 0))
    days_mat = float(row.get("days_to_maturity", 30))
    renewal = float(row.get("renewal_count", 0))
    eng = float(row.get("app_engagement_score", 50))

    # High login gap near maturity = strong churn signal
    urgency_signal = login_gap / max(1, days_mat) if days_mat > 0 else login_gap / 30
    feats.append(urgency_signal)

    # Log-scaled FD amount (loyalty signal)
    feats.append(math.log1p(fd_amt))

    # Engagement × renewal interaction
    feats.append(eng * renewal / 100)

    return feats


# ---------------------------------------------------------------------------
# Simple Gradient Boosting (pure Python — no sklearn required)
# ---------------------------------------------------------------------------

def sigmoid(x):
    return 1.0 / (1.0 + math.exp(-max(-500, min(500, x))))


def log_loss_grad_hess(y_true, y_pred_prob):
    """XGBoost-style gradient and hessian for log loss."""
    grads, hesses = [], []
    for y, p in zip(y_true, y_pred_prob):
        grads.append(p - y)
        hesses.append(max(1e-6, p * (1 - p)))
    return grads, hesses


class SimpleTree:
    """Shallow decision tree for gradient boosting."""

    def __init__(self, max_depth=4, min_samples_leaf=20, lambda_=1.0):
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.lambda_ = lambda_
        self.tree = None

    def _best_split(self, X, grads, hesses):
        best_gain = 0
        best_feat, best_thresh = None, None
        n_feats = len(X[0])
        G = sum(grads)
        H = sum(hesses) + self.lambda_

        for feat_idx in range(n_feats):
            vals = sorted(set(row[feat_idx] for row in X))
            if len(vals) < 2:
                continue
            thresholds = [(vals[i] + vals[i+1]) / 2 for i in range(len(vals)-1)]
            for thresh in thresholds[::max(1, len(thresholds)//20)]:  # sample thresholds
                left_g = left_h = right_g = right_h = 0.0
                left_n = right_n = 0
                for x, g, h in zip(X, grads, hesses):
                    if x[feat_idx] <= thresh:
                        left_g += g; left_h += h; left_n += 1
                    else:
                        right_g += g; right_h += h; right_n += 1
                if left_n < self.min_samples_leaf or right_n < self.min_samples_leaf:
                    continue
                gain = (
                    (left_g**2 / (left_h + self.lambda_)) +
                    (right_g**2 / (right_h + self.lambda_)) -
                    (G**2 / H)
                ) / 2
                if gain > best_gain:
                    best_gain = gain
                    best_feat = feat_idx
                    best_thresh = thresh
        return best_feat, best_thresh, best_gain

    def _leaf_weight(self, grads, hesses):
        G = sum(grads)
        H = sum(hesses) + self.lambda_
        return -G / H

    def _build(self, X, grads, hesses, depth):
        if depth >= self.max_depth or len(X) < self.min_samples_leaf * 2:
            return {"leaf": self._leaf_weight(grads, hesses)}
        feat, thresh, gain = self._best_split(X, grads, hesses)
        if feat is None or gain < 1e-4:
            return {"leaf": self._leaf_weight(grads, hesses)}
        left_idx = [i for i, x in enumerate(X) if x[feat] <= thresh]
        right_idx = [i for i, x in enumerate(X) if x[feat] > thresh]
        return {
            "feat": feat, "thresh": thresh,
            "left": self._build([X[i] for i in left_idx], [grads[i] for i in left_idx], [hesses[i] for i in left_idx], depth+1),
            "right": self._build([X[i] for i in right_idx], [grads[i] for i in right_idx], [hesses[i] for i in right_idx], depth+1),
        }

    def fit(self, X, grads, hesses):
        self.tree = self._build(X, grads, hesses, 0)

    def predict_one(self, x):
        node = self.tree
        while "leaf" not in node:
            if x[node["feat"]] <= node["thresh"]:
                node = node["left"]
            else:
                node = node["right"]
        return node["leaf"]

    def predict(self, X):
        return [self.predict_one(x) for x in X]


class GradientBoostingClassifier:
    def __init__(self, n_estimators=60, learning_rate=0.1, max_depth=4, lambda_=1.0):
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.max_depth = max_depth
        self.lambda_ = lambda_
        self.trees = []
        self.base_score = 0.5

    def fit(self, X, y, verbose=True):
        # Initial raw prediction (log-odds of base_score)
        raw_preds = [math.log(self.base_score / (1 - self.base_score))] * len(X)

        for i in range(self.n_estimators):
            probs = [sigmoid(r) for r in raw_preds]
            grads, hesses = log_loss_grad_hess(y, probs)

            tree = SimpleTree(max_depth=self.max_depth, lambda_=self.lambda_)
            tree.fit(X, grads, hesses)
            self.trees.append(tree)

            updates = tree.predict(X)
            raw_preds = [r + self.learning_rate * u for r, u in zip(raw_preds, updates)]

            if verbose and (i + 1) % 10 == 0:
                probs_upd = [sigmoid(r) for r in raw_preds]
                loss = -sum(
                    y_i * math.log(max(1e-9, p)) + (1 - y_i) * math.log(max(1e-9, 1 - p))
                    for y_i, p in zip(y, probs_upd)
                ) / len(y)
                print(f"  Tree {i+1:3d}/{self.n_estimators} | log-loss: {loss:.4f}")

        return self

    def predict_proba(self, X):
        raw_preds = [math.log(self.base_score / (1 - self.base_score))] * len(X)
        for tree in self.trees:
            updates = tree.predict(X)
            raw_preds = [r + self.learning_rate * u for r, u in zip(raw_preds, updates)]
        return [sigmoid(r) for r in raw_preds]

    def predict(self, X, threshold=0.5):
        return [int(p >= threshold) for p in self.predict_proba(X)]


# ---------------------------------------------------------------------------
# Evaluation Utilities
# ---------------------------------------------------------------------------

def compute_metrics(y_true, y_pred_prob, threshold=0.5):
    y_pred = [int(p >= threshold) for p in y_pred_prob]
    tp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 1 and yp == 1)
    tn = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 0 and yp == 0)
    fp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 0 and yp == 1)
    fn = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 1 and yp == 0)

    accuracy = (tp + tn) / len(y_true)
    precision = tp / max(1, tp + fp)
    recall = tp / max(1, tp + fn)
    f1 = 2 * precision * recall / max(1e-9, precision + recall)

    # ROC-AUC (approximate via sorting)
    pairs = sorted(zip(y_pred_prob, y_true), reverse=True)
    n_pos = sum(y_true)
    n_neg = len(y_true) - n_pos
    auc = 0.0
    tp_count = 0
    for prob, label in pairs:
        if label == 1:
            tp_count += 1
        else:
            auc += tp_count
    auc = auc / max(1, n_pos * n_neg)

    return {
        "accuracy": round(accuracy, 4),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "roc_auc": round(auc, 4),
        "tp": tp, "tn": tn, "fp": fp, "fn": fn,
    }


def print_metrics(metrics: dict):
    print("\n  ┌─────────────────────────────────────┐")
    print(f"  │  Accuracy:  {metrics['accuracy']:.4f}                   │")
    print(f"  │  ROC-AUC:   {metrics['roc_auc']:.4f}                   │")
    print(f"  │  Precision: {metrics['precision']:.4f}  Recall: {metrics['recall']:.4f}  │")
    print(f"  │  F1 Score:  {metrics['f1']:.4f}                   │")
    print(f"  │  TP:{metrics['tp']:5d}  TN:{metrics['tn']:5d}  FP:{metrics['fp']:4d}  FN:{metrics['fn']:4d} │")
    print("  └─────────────────────────────────────┘\n")


# ---------------------------------------------------------------------------
# Data Loading
# ---------------------------------------------------------------------------

def load_csv(path: str):
    rows = []
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Cast numerics
            for k in NUMERIC_FEATURES + BINARY_FEATURES:
                if k in row:
                    row[k] = float(row[k])
            rows.append(row)
    return rows


def train_test_split(rows, test_ratio=0.2, seed=42):
    random.seed(seed)
    shuffled = rows[:]
    random.shuffle(shuffled)
    split = int(len(shuffled) * (1 - test_ratio))
    return shuffled[:split], shuffled[split:]


# ---------------------------------------------------------------------------
# Main Training Pipeline
# ---------------------------------------------------------------------------

def train(data_path: str = "data/fd_customers.csv", model_path: str = "models/churn_v1.pkl"):
    print(f"\n{'='*55}")
    print("  Blostem ChurnSense AI — Model Training Pipeline")
    print(f"{'='*55}")

    print(f"\n[1/4] Loading data from {data_path}...")
    rows = load_csv(data_path)
    print(f"  Loaded {len(rows):,} records")

    print("\n[2/4] Feature engineering...")
    encode_categoricals(rows)
    train_rows, test_rows = train_test_split(rows, test_ratio=0.2)

    X_train = [extract_features(r) for r in train_rows]
    y_train = [int(float(r["churned"])) for r in train_rows]
    X_test  = [extract_features(r) for r in test_rows]
    y_test  = [int(float(r["churned"])) for r in test_rows]

    print(f"  Train: {len(X_train):,} | Test: {len(X_test):,}")
    print(f"  Features: {len(X_train[0])} per record")
    print(f"  Train churn rate: {sum(y_train)/len(y_train)*100:.1f}%")

    print("\n[3/4] Training Gradient Boosting Classifier...")
    model = GradientBoostingClassifier(n_estimators=60, learning_rate=0.08, max_depth=4)
    model.fit(X_train, y_train)

    print("\n[4/4] Evaluating on holdout test set...")
    y_pred_prob = model.predict_proba(X_test)
    metrics = compute_metrics(y_test, y_pred_prob)
    print_metrics(metrics)

    # Save model + encoders
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    payload = {
        "model": model,
        "platform_enc": PLATFORM_ENC,
        "bank_enc": BANK_ENC,
        "state_enc": STATE_ENC,
        "metrics": metrics,
    }
    with open(model_path, "wb") as f:
        pickle.dump(payload, f)
    print(f"  Model saved → {model_path}")

    # Save metrics
    metrics_path = model_path.replace(".pkl", "_metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=2)
    print(f"  Metrics saved → {metrics_path}\n")

    return model, metrics


def load_model(model_path: str = "models/churn_v1.pkl"):
    global PLATFORM_ENC, BANK_ENC, STATE_ENC
    with open(model_path, "rb") as f:
        payload = pickle.load(f)
    PLATFORM_ENC = payload["platform_enc"]
    BANK_ENC = payload["bank_enc"]
    STATE_ENC = payload["state_enc"]
    return payload["model"]


def predict_single(customer: dict, model) -> dict:
    feats = [extract_features(customer)]
    prob = model.predict_proba(feats)[0]
    risk = "LOW" if prob < 0.3 else "MEDIUM" if prob < 0.6 else "HIGH"

    actions = {
        "LOW":    "No action needed. Flag for renewal reminder 7 days before maturity.",
        "MEDIUM": "Send personalized renewal reminder via app notification 14 days before maturity.",
        "HIGH":   "Urgent: trigger WhatsApp outreach + offer 0.25% rate bump. Assign to partner success team.",
    }

    return {
        "customer_id": customer.get("customer_id", "unknown"),
        "churn_probability": round(prob, 4),
        "risk_level": risk,
        "recommended_action": actions[risk],
        "confidence": round(0.75 + (abs(prob - 0.5) * 0.5), 3),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", action="store_true")
    parser.add_argument("--evaluate", action="store_true")
    parser.add_argument("--data", default="data/fd_customers.csv")
    parser.add_argument("--model", default="models/churn_v1.pkl")
    args = parser.parse_args()

    if args.train:
        train(args.data, args.model)
    else:
        print("Run with --train to train the model.")
        print("Example: python src/models/churn_model.py --train --data data/fd_customers.csv")
