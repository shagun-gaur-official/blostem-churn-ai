"""
Blostem ChurnSense AI — Customer Segmentation
RFM-based segmentation + behavioral clustering for FD customers.
"""

import math
import csv
import json
from collections import defaultdict


def compute_rfm_scores(rows: list) -> list:
    """
    Compute RFM scores for FD customers:
    - Recency: days since last login (lower = better)
    - Frequency: renewal count (higher = better)
    - Monetary: FD amount (higher = better)
    """
    recencies = [float(r.get("days_since_login", 30)) for r in rows]
    frequencies = [float(r.get("renewal_count", 0)) for r in rows]
    monetaries = [float(r.get("fd_amount", 50000)) for r in rows]

    def percentile_score(val, vals, ascending=True):
        """Score 1-5 based on percentile rank."""
        sorted_vals = sorted(vals)
        n = len(sorted_vals)
        rank = sum(1 for v in sorted_vals if v <= val) / n
        score = int(rank * 4) + 1
        score = min(5, max(1, score))
        return score if not ascending else 6 - score

    enriched = []
    for i, row in enumerate(rows):
        r_score = percentile_score(recencies[i], recencies, ascending=True)   # low recency = high score
        f_score = percentile_score(frequencies[i], frequencies, ascending=False)  # high freq = high score
        m_score = percentile_score(monetaries[i], monetaries, ascending=False)

        rfm_total = r_score + f_score + m_score
        enriched.append({**row, "r_score": r_score, "f_score": f_score, "m_score": m_score, "rfm_total": rfm_total})

    return enriched


def assign_segment(row: dict) -> str:
    """
    Rule-based segmentation using RFM scores + behavioral signals.
    Maps each customer to one of 5 actionable Blostem segments.
    """
    r = row["r_score"]
    f = row["f_score"]
    m = row["m_score"]
    rfm = row["rfm_total"]
    login_gap = float(row.get("days_since_login", 30))
    days_to_mat = float(row.get("days_to_maturity", 30))
    renewal = float(row.get("renewal_count", 0))
    engagement = float(row.get("app_engagement_score", 50))

    # Champions: high across all dimensions
    if rfm >= 12 and renewal >= 3:
        return "Champions"

    # Engaged Growers: high engagement, growing
    if f >= 3 and m >= 3 and engagement >= 60:
        return "Engaged Growers"

    # At-Risk Dormant: login gap critical near maturity
    if login_gap > 21 and days_to_mat < 20 and days_to_mat > 0:
        return "At-Risk Dormant"

    # Likely Churners: very low recency + low renewal + low engagement
    if r <= 2 and f <= 1 and engagement < 30:
        return "Likely Churners"

    # Passive Holders: everyone else
    return "Passive Holders"


def segment_summary(rows: list) -> dict:
    """Compute summary statistics per segment."""
    segment_data = defaultdict(list)
    for row in rows:
        seg = row.get("blostem_segment", "Unknown")
        segment_data[seg].append(row)

    summary = {}
    for seg, seg_rows in segment_data.items():
        n = len(seg_rows)
        avg_fd = sum(float(r.get("fd_amount", 0)) for r in seg_rows) / n
        avg_churn = sum(float(r.get("churned", 0)) for r in seg_rows) / n
        avg_renewal = sum(float(r.get("renewal_count", 0)) for r in seg_rows) / n
        avg_engagement = sum(float(r.get("app_engagement_score", 0)) for r in seg_rows) / n
        total_fd_value = sum(float(r.get("fd_amount", 0)) for r in seg_rows)

        summary[seg] = {
            "count": n,
            "share_pct": round(n / len(rows) * 100, 1),
            "avg_fd_amount": round(avg_fd),
            "avg_churn_rate": round(avg_churn * 100, 1),
            "avg_renewal_count": round(avg_renewal, 2),
            "avg_engagement_score": round(avg_engagement, 1),
            "total_fd_value_cr": round(total_fd_value / 1e7, 2),  # in crores
        }

    return summary


def run_segmentation(data_path: str = "data/fd_customers.csv", out_path: str = "data/fd_customers_segmented.csv"):
    print(f"\n{'='*55}")
    print("  Blostem ChurnSense AI — Customer Segmentation")
    print(f"{'='*55}\n")

    rows = []
    with open(data_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)

    print(f"[1/3] Loaded {len(rows):,} customer records")

    print("[2/3] Computing RFM scores + assigning segments...")
    rows = compute_rfm_scores(rows)
    for row in rows:
        row["blostem_segment"] = assign_segment(row)

    print("[3/3] Segment summary:\n")
    summary = segment_summary(rows)
    print(f"  {'Segment':<20} {'Count':>6} {'Share':>6} {'Churn%':>7} {'Avg FD (₹)':>12} {'AUM (Cr)':>9}")
    print("  " + "-" * 65)
    for seg, stats in sorted(summary.items(), key=lambda x: -x[1]["count"]):
        print(f"  {seg:<20} {stats['count']:>6,} {stats['share_pct']:>5.1f}% "
              f"{stats['avg_churn_rate']:>6.1f}% ₹{stats['avg_fd_amount']:>10,} "
              f"{stats['total_fd_value_cr']:>8.1f}Cr")

    # Save segmented data
    if out_path:
        import os
        os.makedirs(os.path.dirname(out_path) if os.path.dirname(out_path) else ".", exist_ok=True)
        with open(out_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        print(f"\n  Segmented data → {out_path}")

    # Save summary JSON
    summary_path = out_path.replace(".csv", "_summary.json") if out_path else "data/segment_summary.json"
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"  Segment summary → {summary_path}")

    return rows, summary


SEGMENT_ACTIONS = {
    "Champions": {
        "icon": "🟢",
        "priority": "LOW",
        "actions": [
            "Send VIP appreciation message 30 days before maturity",
            "Offer exclusive higher-tenor rate as loyalty reward",
            "Request referral / NPS survey",
            "Consider for beta access to new Blostem products",
        ],
    },
    "Engaged Growers": {
        "icon": "🔵",
        "priority": "LOW-MEDIUM",
        "actions": [
            "Suggest tenor upgrade (6M → 12M) with rate benefit",
            "Cross-sell Recurring Deposits",
            "Highlight partner platform benefits (if on Upstox/Jupiter)",
        ],
    },
    "Passive Holders": {
        "icon": "🟡",
        "priority": "MEDIUM",
        "actions": [
            "Send reactivation nudge via app push notification",
            "Show FD comparison widget (current vs better rate)",
            "Highlight auto-renewal benefits",
        ],
    },
    "At-Risk Dormant": {
        "icon": "🟠",
        "priority": "HIGH",
        "actions": [
            "URGENT: WhatsApp outreach 21 days before maturity",
            "Offer 0.25% rate bump for renewal commitment",
            "Assign to partner success team for personal call",
            "Show personalized FD simulator with renewal outcome",
        ],
    },
    "Likely Churners": {
        "icon": "🔴",
        "priority": "CRITICAL",
        "actions": [
            "CRITICAL: Match competitive rate + flag to ops team",
            "Trigger exit-intent survey: why are you leaving?",
            "Offer rate guarantee on next renewal if they stay",
            "Escalate to Blostem platform team for B2B intervention",
        ],
    },
}


if __name__ == "__main__":
    import sys
    data = sys.argv[1] if len(sys.argv) > 1 else "data/fd_customers.csv"
    run_segmentation(data)
